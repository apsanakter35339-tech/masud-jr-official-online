const API_BASE='https://masud-jr-official-online.onrender.com';
const LOCK=86400000;
let S=localStorage.getItem('mjrUserSession')||'';
let ME=null;
const $=id=>document.getElementById(id);
async function api(url,opts={}){const r=await fetch(API_BASE+url,{...opts,headers:{'Content-Type':'application/json','x-user-session':S,...(opts.headers||{})}});let d={};try{d=await r.json()}catch{}if(!r.ok)throw Error(d.error||'Request failed');return d}
function showAuth(x){$('registerBox').style.display=x==='r'?'block':'none';$('loginBox').style.display=x==='l'?'block':'none';$('rt').classList.toggle('active',x==='r');$('lt').classList.toggle('active',x==='l')}
async function registerUser(){const n=$('registerName').value.trim(),p=$('registerPassword').value;if(!n||!p){$('registerMessage').innerText='⚠️ নাম ও পাসওয়ার্ড দিন।';return}try{const d=await api('/api/register',{method:'POST',body:JSON.stringify({name:n,password:p})});setSession(d);alert('🎉 রেজিস্ট্রেশন সফল হয়েছে!');openDashboard()}catch(e){$('registerMessage').innerText='⚠️ '+e.message}}
async function login(){const n=$('username').value.trim(),p=$('password').value;if(!n||!p){$('loginMessage').innerText='⚠️ নাম ও পাসওয়ার্ড দিন।';return}try{const d=await api('/api/login',{method:'POST',body:JSON.stringify({name:n,password:p})});setSession(d);openDashboard()}catch(e){$('loginMessage').innerText='❌ '+e.message}}
function setSession(d){S=d.session;ME=d.user;localStorage.setItem('mjrUserSession',S)}
async function logout(){try{if(S)await api('/api/logout',{method:'POST'})}catch{}S='';ME=null;localStorage.removeItem('mjrUserSession');$('dashboard').style.display='none';$('loginPage').style.display='flex';$('username').value='';$('password').value='';showAuth('l')}
function openDashboard(){$('loginPage').style.display='none';$('dashboard').style.display='block';init()}
function openCustomerService(){window.open('https://m.me/masud.11.jr','_blank')}
function openWhatsApp(){window.open('https://wa.me/8801961504587','_blank')}
function showPage(id){document.querySelectorAll('main section').forEach(x=>x.classList.add('hide'));$(id).classList.remove('hide');if(id==='homeSection')update();if(id==='tasksSection')drawTasks();if(id==='trucksSection')drawVideos();if(id==='balanceSection'){updateBalance();drawFeePayment();}if(id==='historySection')drawHistory();if(id==='profileSection')updateProfile();if(id==='noticeSection')drawNotices()}
async function init(){try{const d=await api('/api/me');ME=d.user;update();drawTasks();drawVideos();updateBalance();drawFeePayment();updateProfile();drawHistory();drawNotices()}catch{logout()}}
function update(){if(!ME)return;$('homeBalance').innerText=ME.balance;$('todayIncome').innerText='—';$('totalIncome').innerText=ME.totalIncome}
function updateBalance(){if(!ME)return;$('balanceAmount').innerText=ME.balance;$('balanceToday').innerText='—';$('balanceTotal').innerText=ME.totalIncome}
function updateProfile(){if(!ME)return;$('homeUsername').innerText=ME.name;$('profileName').innerText=ME.name;$('profileUserId').innerText=ME.userId}
async function drawTasks(){try{const a=await api('/api/tasks');$('tasks').innerHTML=a.length?a.map(x=>`<div class="task"><div class="info"><h3>${esc(x.title)}</h3><p>Reward: <b>৳${x.reward}</b></p><p>⏱️ অপেক্ষা: <b>${Number(x.countdown_seconds)||10} সেকেন্ড</b></p><p class="fixed-link"><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">🔗 Task Link</a></p></div><button ${x.completed?'disabled':''} onclick="openTaskAndReward(${x.id},'${escAttr(x.url)}',${Number(x.countdown_seconds)||10})">${x.completed?'Completed':'🔗 Task শুরু করুন'}</button><p id="task-status-${x.id}" class="status">${x.completed?'✅ এই Task-এর Reward নেওয়া হয়েছে।':'বাটনে চাপলে Link খুলবে, তারপর '+(Number(x.countdown_seconds)||10)+' সেকেন্ড countdown চলবে।'}</p></div>`).join(''):'<div class="card">এখন কোনো Task নেই।</div>'}catch(e){$('tasks').innerHTML='<div class="card">'+esc(e.message)+'</div>'}}
async function openTaskAndReward(id,url,seconds){
  const popup=window.open('about:blank','_blank');
  try{
    const d=await api('/api/tasks/'+id+'/start',{method:'POST'});
    if(popup){popup.location.href=url;}else{window.open(url,'_blank');}
    const status=$('task-status-'+id);
    let left=Math.max(1,Number(d.countdownSeconds)||seconds||10);
    const tick=()=>{if(!status)return;status.innerText='⏳ Task চলছে — '+left+' সেকেন্ড বাকি...';if(left<=0)return clearInterval(timer);left--;};
    tick();const timer=setInterval(tick,1000);
    await new Promise(r=>setTimeout(r,(Math.max(1,Number(d.countdownSeconds)||seconds||10))*1000));
    clearInterval(timer);
    status.innerText='⏳ যাচাই হচ্ছে...';
    const done=await api('/api/tasks/'+id+'/complete',{method:'POST'});
    ME=done.user;update();updateBalance();drawTasks();drawHistory();
    alert('🎉 Task Complete! ৳'+done.reward+' আপনার Balance-এ যোগ হয়েছে।');
  }catch(e){if(popup)try{popup.close()}catch{};alert('⚠️ '+e.message);drawTasks();}
}
async function drawVideos(){try{const a=await api('/api/trucks'),now=Date.now();$('videos').innerHTML=a.map(x=>{const last=Number(x.completed_at)||0,r=LOCK-(now-last),locked=last&&r>0,h=locked?Math.floor(r/3600000)+' ঘণ্টা '+Math.floor(r%3600000/60000)+' মিনিট পরে আবার করা যাবে':'🟢 Available — Reward ৳'+x.reward;return `<div class="video"><div class="info"><h3>${esc(x.title)}</h3><p>Reward: <b>৳${x.reward}</b></p></div><button ${locked?'disabled':''} onclick="openTruckVideo(${x.id},'${escAttr(x.url)}')">ভিডিও খুলুন</button><p class="status">${locked?'🔒 লক — '+h:h}</p></div>`}).join('')}catch(e){$('videos').innerHTML='<div class="card">'+esc(e.message)+'</div>'}}
async function openTruckVideo(id,url){window.open(url,'_blank');try{const d=await api('/api/trucks/'+id+'/complete',{method:'POST'});ME=d.user;update();updateBalance();drawVideos();drawHistory();alert('🎉 ভিডিও Reward হিসেবে ৳'+d.reward+' যোগ হয়েছে!')}catch(e){alert('⚠️ '+e.message)}}
async function drawHistory(){try{const h=await api('/api/history');$('historyList').innerHTML=h.length?h.map(x=>`<div class="history"><b>${esc(x.task)}</b><br>💰 Reward: ৳${x.reward}<br>🕒 ${esc(x.created_at)}<br><span class="ok">Status: ${esc(x.status)}</span></div>`).join(''):'<div class="card">এখনো কোনো History নেই।</div>'}catch(e){$('historyList').innerHTML='<div class="card">'+esc(e.message)+'</div>'}}
async function drawNotices(){try{const a=await api('/api/notices');$('noticeSection').innerHTML='<h2>📢 নোটিশ</h2>'+(a.length?a.map(x=>`<div class="card"><b>${esc(x.title)}</b><p>${esc(x.body)}</p></div>`).join(''):'<div class="card">এখন কোনো Notice নেই।</div>')}catch(e){$('noticeSection').innerHTML='<h2>📢 নোটিশ</h2><div class="card">'+esc(e.message)+'</div>'}}
async function withdrawMoney(){if(!ME||ME.balance<200){alert('⚠️ সর্বনিম্ন উত্তোলনের পরিমাণ ৳২০০।');return}let a=prompt('💰 টাকার পরিমাণ লিখুন\nসর্বনিম্ন: ৳২০০');if(a===null)return;a=Number(a);if(!Number.isFinite(a)||a<200||a>ME.balance){alert('⚠️ সঠিক পরিমাণ লিখুন।');return}let m=prompt('পেমেন্ট মাধ্যম নির্বাচন করুন:\n1 = bKash\n2 = Nagad\n3 = Rocket');let mm={'1':'bKash','2':'Nagad','3':'Rocket'};if(!mm[m]){alert('⚠️ bKash, Nagad অথবা Rocket নির্বাচন করুন।');return}let account=prompt(mm[m]+' Account Number লিখুন');if(account===null||!account.trim())return;try{const d=await api('/api/withdrawals',{method:'POST',body:JSON.stringify({amount:a,method:mm[m],account:account.trim()})});ME=d.user;update();updateBalance();alert('💸 টাকা উত্তোলনের অনুরোধ পাঠানো হয়েছে।\n\nমাধ্যম: '+mm[m]+'\nটাকার পরিমাণ: ৳'+a+'\nপ্রসেসিং/সার্ভিস ফি: ৳70\n\nAdmin Panel থেকে অনুরোধটি দেখা যাবে।')}catch(e){alert('⚠️ '+e.message)}}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function escAttr(v){return esc(v).replace(/`/g,'&#096;')}
document.addEventListener('DOMContentLoaded',async()=>{showAuth('r');if(S){$('loginPage').style.display='none';$('dashboard').style.display='block';await init()}});
